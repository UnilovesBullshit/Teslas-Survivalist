// Listen to item registry event
StartupEvents.registry('item', event => {
    // The texture for this item has to be placed in kubejs/assets/kubejs/textures/item/test_item.png
    event.create('asbestos_sheet')
    .displayName('Asbestos Based Insulator Sheet')
    .fireResistant(true)

    event.create('blaze_ritual')
    .displayName('Blaze Summoning Ritual')

    event.create('skeleton_ritual')
    .displayName('Skeleton Summoning Ritual')

  })