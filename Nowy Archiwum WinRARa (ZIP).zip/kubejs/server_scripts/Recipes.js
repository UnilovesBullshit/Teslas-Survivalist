ServerEvents.recipes(event => {
    // Removing/Modyfing recipes
    event.remove({ mod: 'constructionwand' })
    event.remove({ mod: 'createloveandwar' })
    event.remove({ mod: 'gtceu' })
    event.remove({ mod: 'cataclysm' })
    event.remove({ mod: 'occultism' })
    event.remove({ mod: 'create_new_age' })
    event.remove({ mod: 'alloyed' })
    event.remove({ mod: 'irons_spellbooks' })
    event.remove({ id: 'create:crafting/kinetics/mechanical_pump' })
    event.remove({ id: 'create:crafting/kinetics/mechanical_drill' })
    event.remove({ id: 'create:crafting/kinetics/steam_engine' })
    event.remove({ id: 'minecraft:blaze_powder' })
    event.remove({ id: 'create:crushing/blaze_rod' })
    event.remove({ id: 'create:crafting/materials/zinc_block_from_compacting' })
    event.remove({ id: 'create:compacting/blaze_cake' })
    event.remove({ id: 'create:sequenced_assembly/sturdy_sheet' })
    event.remove({ id: 'create_enchantment_industry:mixing/hyper_expirience' })
    event.remove({ output: 'minecraft:paper' })
    event.remove({ output: 'create:pulp' })
    event.remove({ output: 'create:cardboard' })
    event.remove({id: 'minecraft:diamond_axe'})
    event.remove({id: 'minecraft:diamond_pickaxe'})
    event.remove({id: 'minecraft:diamond_shovel'})
    event.remove({id: 'minecraft:diamond_hoe'})
    event.remove({id: 'minecraft:diamond_sword'})
    event.remove({id: 'minecraft:diamond_boots'})
    event.remove({id: 'minecraft:diamond_chestplate'})
    event.remove({id: 'minecraft:diamond_leggings'})
    event.remove({id: 'minecraft:diamond_helmet'})
    event.remove({id: 'create_enchantment_industry:crafting/enchanting_guide'})
    
    event.replaceInput(
      { id:'minecraft:enchanting_table' }, 
      'minecraft:diamond',            
      'irons_spellbooks:arcane_ingot'      
    )
    
    event.replaceInput(
      { id:'create:crafting/kinetics/mechanical_press' }, 
      'minecraft:iron_block',            
      'minecraft:anvil'      
    )

    event.replaceInput(
      { id:'create:crafting/kinetics/item_vault' }, 
      'create:iron_sheet',            
      'gtceu:steel_plate'      
    )

    event.replaceInput(
      { input: '#forge:rods/wooden' }, 
      '#forge:rods/wooden',            
      'minecraft:stick'      
    )
    
    event.replaceInput(
      { input: 'create:golden_sheet' }, 
      'create:golden_sheet',            
      'create:brass_sheet'      
    )
    event.replaceInput(
      { id: 'create:pressing/gold_ingot'},
      'create:brass_sheet',            
      'create:golden_sheet' 
    )

    event.replaceInput(
      { id:'create:crafting/kinetics/mechanical_harvester' }, 
      'create:andesite_alloy',            
      'gtceu:steel_rod'      
    )

    event.replaceInput(
      { id:'create:crafting/kinetics/mechanical_saw' }, 
      'create:iron_sheet',            
      'gtceu:steel_plate'      
    )

    event.replaceInput(
      { id:'create:crafting/kinetics/mechanical_saw' }, 
      'minecraft:iron_ingot',            
      'create:andesite_alloy'      
    )


    event.replaceInput(
      { id:'create:crafting/kinetics/mechanical_crafter' }, 
      'create:electron_tube',            
      'create:cogwheel'      
    )

    event.replaceInput(
      { input: 'create:zinc_ingot' }, 
      'create:zinc_ingot',            
      'gtceu:zinc_ingot'        
    )
    event.replaceOutput(
      { output: 'create:zinc_ingot' }, 
      'create:zinc_ingot',            
      'gtceu:zinc_ningot'        
    )
    event.replaceOutput(
      { output: 'create:zinc_nugget' }, 
      'create:zinc_nugget',            
      'gtceu:zinc_nugget'        
    )
    event.replaceInput(
      { input: 'create:zinc_nugget' }, 
      'create:zinc_nugget',            
      'gtceu:zinc_nugget'        
    )

    event.replaceInput(
      { input: '#forge:ingots/brass' }, 
      '#forge:ingots/brass',            
      'create:brass_ingot'        
    )

    event.replaceInput(
      { input: '#forge:plates/brass' }, 
      '#forge:plates/brass',            
      'create:brass_sheet'        
    )

    event.replaceInput(
      { input: '#forge:plates/iron' }, 
      '#forge:plates/iron',            
      'create:iron_sheet'        
    )

    event.replaceInput(
      { input: '#forge:plates/copper' }, 
      '#forge:plates/copper',            
      'create:copper_sheet'        
    )

    event.replaceInput(
      { input: '#forge:plates/obsidian' }, 
      '#forge:plates/obsidian',            
      'create:sturdy_sheet'        
    )

    event.replaceInput(
      { input: '#forge:plates/gold' }, 
      '#forge:plates/gold',            
      'create:golden_sheet'        
    )


    event.replaceInput(
      { input: 'create:electron_tube' }, 
      'create:electron_tube',            
      'gtceu:vacuum_tube'        
    )

    event.replaceInput(
      { input: 'minecraft:dried_kelp'} && {type: 'minecraft:crafting'} && {not:{id: 'minecraft:dried_kelp_block'}}, 
      'minecraft:dried_kelp',            
      'gtceu:rubber_ingot'        
    )

    event.replaceInput(
      {id: 'farmersdelight:kelp_roll'}, 
      'gtceu:rubber_ingot',
      'minecraft:dried_kelp'            
    )
    
    //Energising gen
    function CreateEnergising(output, outputCount, input, inputCount, energy){
      event.custom({
        "type": "create_new_age:energising",
        "energy_needed": energy,
        "ingredients": [
          {
            "item": input,
            "count": inputCount
          }
        ],
        "results": [
          {
            "item": output,
            "count": outputCount
          }
        ]
      }
      )  
    }
    
    //Rods
      function GTrods(input) {
        event.shaped(Item.of('gtceu:' + input + '_rod', 2), [
          'A',
          'A'
        ], {
          A: 'gtceu:' + input + '_ingot'
        })
      }
      function Vannilarods(input) {
        event.shaped(Item.of('gtceu:' + input + '_rod', 2), [
          'A',
          'A'
        ], {
          A: 'minecraft:' + input + '_ingot'
        })
      }
    
    
    



    function Wiremaking(input){
      event.recipes.create.cutting(Item.of('gtceu:' + input + '_single_wire', 2), 'gtceu:' + input + '_rod')
    }

    function Wire1compacting(input){
      event.shapeless(
        'gtceu:' + input + '_double_wire', 
        [
          '2x gtceu:' + input + '_single_wire',

        ]
      )
    }

    function Wire2compacting(input){
      event.shapeless(
        'gtceu:' + input + '_quadruple_wire', 
        [
          '2x gtceu:' + input + '_double_wire',

        ]
      )
    }

    function Wire1decompacting(input){
      event.shapeless(
        Item.of('gtceu:' + input + '_single_wire', 2), 
        [
          '1x gtceu:' + input + '_double_wire',

        ]
      )
    }

    function Wire2decompacting(input){
      event.shapeless(
        Item.of('gtceu:' + input + '_double_wire', 2), 
        [
          '1x gtceu:' + input + '_quadruple_wire',

        ]
      )
    }

    function GTplates(input) {
      event.recipes.create.pressing(Item.of('gtceu:' + input + '_plate').withChance(0.5), 'gtceu:' + input + '_ingot')

      event.recipes.gtceu.bender('plate' + input + 'making')
      .itemInputs(
          'gtceu:' + input + '_ingot'
      )
      .itemOutputs(
          'gtceu:' + input + '_plate'
      )
      .duration(50)
      .EUt(16)
    }

    //Compression and Decompression of materials
    function GTcompressB(input) {
      event.shapeless(
        'gtceu:' + input + '_block', 
        [
          '9x gtceu:' + input + '_ingot',

        ]
      )
    }

    function GTdecompressB(input) {
      event.shapeless(
        Item.of('gtceu:' + input + '_ingot', 9), 
        [
          'gtceu:' + input + '_block',

        ]
      )
    }

    function GTcompressI(input) {
      event.shapeless(
        'gtceu:' + input + '_ingot', 
        [
          '9x gtceu:' + input + '_nugget',

        ]
      )
    }

    function GTdecompressI(input) {
      event.shapeless(
        Item.of('gtceu:' + input + '_nugget', 9), 
        [
          'gtceu:' + input + '_ingot',

        ]
      )
    }
      
      function GTcables(input) {
        Wiremaking(input)
        Wire1compacting(input)
        Wire2compacting(input)
        Wire1decompacting(input)
        Wire2decompacting(input)
        InsulatingWires(input)
    }
    
  function Dustproducts(input, output){
    event.recipes.create.crushing(output, input)
  }


      //GT plates and compression gen
      function GTproducts(input) {
        GTplates(input)
        GTcompressB(input)
        GTcompressI(input)
        GTdecompressB(input)
        GTdecompressI(input)
      }
      
      //Compression gen
      function Compression(input) {
        GTcompressB(input)
        GTcompressI(input)
        GTdecompressB(input)
        GTdecompressI(input)
      }

      //GT smeltable gen
      function GTSmeltable(input){
      event.smelting('gtceu:' + input + '_ingot', 'gtceu:raw_' + input)

      }

      function InsulatingWires(input){
        event.recipes.create.deploying('gtceu:' + input + '_single_cable', ['gtceu:' + input + '_single_wire', 'gtceu:rubber_ingot'])
      }


    
      //GT Materials
      GTproducts('red_alloy')
      GTproducts('steel')
      GTproducts('aluminium')
      GTproducts('stainless_steel')
      GTproducts('invar')
      GTproducts('cupronickel')

      //GT Smeltable
      event.smelting('gtceu:silver_ingot', 'gtceu:silver_dust')
      event.smelting('gtceu:zinc_ingot', 'create:raw_zinc')
      GTSmeltable('silver')

      //GT Dusts
      Dustproducts('#minecraft:logs', [Item.of('gtceu:wood_dust', 1), Item.of('gtceu:wood_dust', 1).withChance(0.5)])
      Dustproducts('gtceu:raw_redstone', [Item.of('minecraft:redstone', 2), Item.of('minecraft:redstone', 2).withChance(0.5)])
      Dustproducts('minecraft:coal', [Item.of('gtceu:coal_dust', 1), Item.of('gtceu:coal_dust', 2).withChance(0.25)])
      Dustproducts('gtceu:raw_sulfur', [Item.of('gtceu:sulfur_dust', 1), Item.of('gtceu:sulfur_dust', 1).withChance(0.25)])
      Dustproducts('minecraft:blaze_rod',[Item.of('minecraft:blaze_powder', 1), Item.of('minecraft:blaze_powder', 1).withChance(0.5)])
      Dustproducts('gtceu:silver_ingot', 'gtceu:silver_dust')
      Dustproducts('gtceu:raw_asbestos', [Item.of('gtceu:asbestos_dust', 1), Item.of('gtceu:asbestos_dust', 1).withChance(0.5)])
      Dustproducts('gtceu:raw_aluminium', [Item.of('gtceu:crushed_aluminium_ore', 1), Item.of('create:expirience_nugget', 1)])
      //Compression materials
      Compression('zinc')

      //Rod Materials
      Vannilarods('iron')
      Vannilarods('copper')
      Vannilarods('gold')
      GTrods('red_alloy')
      GTrods('steel')
      GTrods('cupronickel')

      //Cable products
      GTcables('copper')
      GTcables('iron')
      GTcables('red_alloy')
      GTcables('steel')
      GTcables('gold')
      GTcables('cupronickel')

      //nickel wires cause rods dont exist godamnit
      event.recipes.create.cutting(Item.of('gtceu:nickel_single_wire', 2), 'gtceu:nickel_ingot')
      Wire1compacting('nickel')
      Wire2compacting('nickel')
      Wire1decompacting('nickel')
      Wire2decompacting('nickel')
      InsulatingWires('nickel')

      //Vannila Manual Recipies

      //Steel Tools
      event.shaped(Item.of('alloyed:steel_pickaxe', 1), [
        'AAA',
        ' B ',
        ' B '
      ], {
        A: 'gtceu:steel_ingot',
        B: 'minecraft:stick'
      })

      event.shaped(Item.of('alloyed:steel_axe', 1), [
        'AA',
        'BA',
        'B '
      ], {
        A: 'gtceu:steel_ingot',
        B: 'minecraft:stick'
      })

      event.shaped(Item.of('alloyed:steel_hoe', 1), [
        'AA',
        'B ',
        'B '
      ], {
        A: 'gtceu:steel_ingot',
        B: 'minecraft:stick'
      })

      event.shaped(Item.of('alloyed:steel_shovel', 1), [
        'A',
        'B',
        'B'
      ], {
        A: 'gtceu:steel_ingot',
        B: 'minecraft:stick'
      })

      event.shaped(Item.of('alloyed:steel_sword', 1), [
        'A',
        'A',
        'B'
      ], {
        A: 'gtceu:steel_ingot',
        B: 'minecraft:stick'
      })

      event.shaped(Item.of('alloyed:steel_helmet', 1), [
        'AAA',
        'A A'
      ], {
        A: 'gtceu:steel_ingot'
      })
      
      event.shaped(Item.of('alloyed:steel_chestplate', 1), [
        'A A',
        'AAA',
        'AAA'
      ], {
        A: 'gtceu:steel_ingot'
      })

      event.shaped(Item.of('alloyed:steel_leggings', 1), [
        'AAA',
        'A A',
        'A A'
      ], {
        A: 'gtceu:steel_ingot'
      })

      event.shaped(Item.of('alloyed:steel_boots', 1), [
        'A A',
        'A A'
      ], {
        A: 'gtceu:steel_ingot'
      })

    
      //Mechanical Pump
      event.shaped(Item.of('create:mechanical_pump', 1), [
        'A ',
        'BC',
        'A '
      ], {
        A: 'gtceu:rubber_ingot',
        B: 'create:fluid_pipe',
        C: 'create:cogwheel'
      })

      //Steam Engine
      event.shaped(Item.of('create:steam_engine', 1), [
        'ADA',
        ' B ',
        'CEC'
      ], {
        A: 'gtceu:steel_rod',
        B: 'gtceu:steel_ingot',
        C: 'create:copper_sheet',
        D: 'create:precision_mechanism',
        E: 'gtceu:rubber_ingot'
      })

      //Vacuum Tube
      event.shaped(Item.of('gtceu:vacuum_tube', 1), [
        'A A',
        'ABA',
        'CBC'
      ], {
        A: 'gtceu:steel_rod',
        B: 'minecraft:glass',
        C: 'gtceu:red_alloy_single_wire'
      })

      //LV Circut
      event.shaped(Item.of('gtceu:basic_electronic_circuit', 1), [
        'ABA',
        'CCC',
        'BBB'
      ], {
        A: 'gtceu:vacuum_tube',
        B: 'gtceu:wood_plate',
        C: 'gtceu:red_alloy_single_cable'
      })

      //LV Machine Casing
      event.shaped(Item.of('gtceu:lv_machine_casing', 1), [
        'AAA',
        'B B',
        'AAA'
      ], {
        A: 'gtceu:steel_plate',
        B: 'create:iron_sheet'
      })

      //LV Machine Hull
      event.shaped(Item.of('gtceu:lv_machine_hull', 1), [
        ' A ',
        'BCB'
      ], {
        A: 'gtceu:basic_electronic_circuit',
        B: 'gtceu:nickel_single_cable',
        C: 'gtceu:lv_machine_casing'
      })

      //Generator Coils
      event.shaped(Item.of('create_new_age:generator_coil', 1), [
        'BAB',
        'ACA',
        'BAB'
      ], {
        A: 'gtceu:rubber_ingot',
        B: 'gtceu:copper_quadruple_wire',
        C: 'gtceu:lv_machine_casing'
      })

      //Soft Mallet
      event.shaped(Item.of('gtceu:rubber_mallet', 1), [
        ' A ',
        ' BA',
        'B  '
      ], {
        A: 'gtceu:rubber_ingot',
        B: 'gtceu:steel_rod'
      })

      //Wire Cutter
      event.shaped(Item.of('gtceu:steel_wire_cutter', 1), [
        'A ',
        'BA'
      ], {
        A: 'gtceu:steel_plate',
        B: 'gtceu:steel_rod'
      })

      //LV Prospector
      event.shaped(Item.of('gtceu:prospector.lv', 1), [
        'ABA',
        'BDB',
        'CBC'
      ], {
        A: 'create:transmitter',
        B: 'gtceu:steel_plate',
        C: 'gtceu:basic_electronic_circuit',
        D: 'create:display_board'
      })
      //LV 1A Energy Converter
      event.shaped(Item.of('gtceu:lv_1a_energy_converter', 1), [
        'ABA',
        'BCB',
        'ABA'
      ], {
        A: 'gtceu:rubber_ingot',
        B: 'gtceu:nickel_quadruple_wire',
        C: 'gtceu:lv_machine_hull',
      })

      //LV Alloy Smelter
      event.shaped(Item.of('gtceu:lv_alloy_smelter', 1), [
        'AAA',
        'BCB',
        'AAA'
      ], {
        A: 'gtceu:steel_plate',
        B: 'minecraft:furnace',
        C: 'gtceu:lv_machine_hull',
      })

      //LV Bender
      event.shaped(Item.of('gtceu:lv_bender', 1), [
        'ABA',
        'BCB',
        'ABA'
      ], {
        A: 'gtceu:steel_plate',
        B: 'create:mechanical_piston',
        C: 'gtceu:lv_machine_hull',
      })

      //LV Centrifuge
      event.shaped(Item.of('gtceu:lv_centrifuge', 1), [
        'BAB',
        'BDB',
        'ACA'
      ], {
        A: 'gtceu:steel_plate',
        B: 'minecraft:glass_bottle',
        C: 'create:flywheel',
        D: 'gtceu:lv_machine_hull'
      })

      //LV Energiser
      event.shaped(Item.of('create_new_age:energiser_t1', 1), [
        'ACA',
        'DBD',
        ' B '
      ], {
        A: 'gtceu:polyethylene_ingot',
        B: 'minecraft:lightning_rod',
        C: 'gtceu:lv_machine_hull',
        D: 'gtceu:basic_electronic_circuit'
      })

      //LV Autoclave
      event.shaped(Item.of('gtceu:lv_autoclave', 1), [
        'ADA',
        'CBC',
        'ADA'
      ], {
        A: 'gtceu:steel_plate',
        B: 'gtceu:lv_machine_casing',
        C: 'gtceu:steel_fluid_cell',
        D: 'gtceu:basic_electronic_circuit'
      })

      //Heat Casings
      event.shaped(Item.of('gtceu:heatproof_machine_casing', 1), [
        'AAA',
        'A A',
        'AAA'
      ], {
        A: 'gtceu:invar_plate'
      })

      //Energy Hatch
      event.shaped(Item.of('gtceu:lv_energy_input_hatch', 1), [
        ' A ',
        'ABA',
        ' A '
      ], {
        A: 'gtceu:nickel_quadruple_wire',
        B: 'gtceu:lv_machine_hull',
      })

      //Input Bus (Items)
      event.shaped(Item.of('gtceu:lv_input_bus', 1), [
       'A',
       'B',

       ], {
      A: 'create:smart_chute',
      B: 'gtceu:lv_machine_hull',
      })

      //Input Hatch (Fluids)
      event.shaped(Item.of('gtceu:lv_input_hatch', 1), [
        'A',
        'B',
 
        ], {
       A: 'create:smart_fluid_pipe',
       B: 'gtceu:lv_machine_hull',
       })

      //Input/Output Bus conversion
      event.shapeless(
        'gtceu:lv_input_bus', 
        'gtceu:lv_output_bus')

      event.shapeless(
        'gtceu:lv_output_bus',
        'gtceu:lv_input_bus')

      //Input/Output Hatch conversion
      event.shapeless(
        'gtceu:lv_input_hatch', 
        'gtceu:lv_output_hatch')

      event.shapeless(
        'gtceu:lv_output_hatch',
        'gtceu:lv_input_hatch')




      //Muffler Hatch
      event.shaped(Item.of('gtceu:lv_muffler_hatch', 1), [
       'A',
       'B',

       ], {
      A: 'create:chute',
      B: 'gtceu:lv_machine_casing',
      })

      //Maitenence Hatch
      event.shaped(Item.of('gtceu:maintenance_hatch', 1), [
        'CAC',
        'ABA',
        'CAC'
        ], {
        A: 'gtceu:duct_tape',
        B: 'gtceu:lv_machine_casing',
        C: 'gtceu:steel_plate'
      })

      //EBF
      event.shaped(Item.of('gtceu:electric_blast_furnace', 1), [
        'AAA',
        'CBC',
        'AAA'
        ], {
        A: 'gtceu:heatproof_machine_casing',
        B: 'gtceu:lv_alloy_smelter',
        C: 'create:item_vault'
      })
  


      //Arcane Ingot
      event.shaped(Item.of('irons_spellbooks:arcane_ingot', 1), [
        'AAA',
        'ABA',
        'AAA'
      ], {
        A: 'irons_spellbooks:arcane_essence',
        B: 'gtceu:silver_ingot',
      })


      //Smelting
      event.smelting('2x minecraft:iron_ingot', 'create_new_age:magnetite_block').xp(0.35)

      event.smelting('minecraft:diamond', 'gtceu:raw_diamond').xp(2)

      event.smelting('minecraft:lapis_lazuli', 'gtceu:raw_lapis').xp(1)

      event.smelting('gtceu:nickel_ingot', 'gtceu:raw_nickel').xp(0.5)

      event.smelting('gtceu:nickel_ingot', 'create:crushed_raw_nickel').xp(0.5)

      event.smelting('gtceu:silver_ingot', 'gtceu:raw_silver').xp(0.5)

      //Blasting

      event.blasting('2x minecraft:iron_ingot', 'create_new_age:magnetite_block').xp(0.35)

      event.blasting('minecraft:diamond', 'gtceu:raw_diamond').xp(2)

      event.blasting('minecraft:lapis_lazuli', 'gtceu:raw_lapis').xp(1)

      event.blasting('gtceu:nickel_ingot', 'gtceu:raw_nickel').xp(0.5)

      event.blasting('gtceu:nickel_ingot', 'create:crushed_raw_nickel').xp(0.5)

      event.blasting('gtceu:silver_ingot', 'gtceu:raw_silver').xp(0.5)

      

      //Create Manual Recipies
      //Sulfuric Acid Making
      event.recipes.create.mixing(Fluid.of('gtceu:sulfuric_acid', 1000), [Item.of('gtceu:sulfur_dust', 16), Fluid.water(1000)]).heated()

      event.recipes.create.mixing(Fluid.of('gtceu:sulfuric_acid', 200),[Item.of('gtceu:sulfur_dust', 1), Fluid.of('gtceu:diluted_sulfuric_acid', 200)])

      //Silicon Making
      event.recipes.create.mixing([Item.of('gtceu:silicon_dust', 1),Fluid.of('gtceu:diluted_sulfuric_acid', 100)], [Item.of('gtceu:silicon_dioxide_dust', 1), Fluid.of('gtceu:sulfuric_acid', 100)])

      //Galium Arsenide Making
      event.recipes.create.mixing(Item.of('gtceu:gallium_arsenide_dust', 2), [Item.of('gtceu:arsenic_dust', 1), Item.of('gtceu:gallium_dust', 1)])

      //Steel Making
      event.recipes.create.mixing('gtceu:steel_ingot', [Item.of('minecraft:iron_ingot', 2), Item.of('minecraft:coal', 3), Fluid.lava(100)]).superheated()

      //Red Alloy Making
      event.recipes.create.mixing('gtceu:red_alloy_ingot', [Item.of('minecraft:copper_ingot', 1), Item.of('minecraft:redstone', 4)]).heated()

      //Rubber Making
      event.recipes.create.mixing('gtceu:rubber_ingot', [Item.of('gtceu:wood_dust', 4), Item.of('gtceu:sulfur_dust', 1)]).heated()

      //Arsenic Purification
      event.recipes.create.mixing([Item.of('gtceu:arsenic_dust'), Item.of('gtceu:ash_dust', 3)], [Item.of('gtceu:arsenic_trioxide_dust', 1), Item.of('minecraft:charcoal', 2)]).heated()

      //Fertiliser
      event.recipes.create.compacting('gtceu:fertilizer', [Fluid.of('gtceu:biomass', 10), Item.of('gtceu:wood_dust')]).heated()

      //Paper Making
      event.recipes.create.compacting('minecraft:paper', [Item.of('gtceu:wood_dust', 1), Fluid.water(250)])

      //Cardboard Making
      event.recipes.create.compacting('create:cardboard', [Item.of('minecraft:paper', 3)])

      //Blaze cake base
      event.recipes.create.compacting('create:blaze_cake_base', [Item.of('gtceu:sulfur_dust', 1), Item.of('minecraft:blaze_powder', 3)]).heated()

      //LV Magnet Making
      event.recipes.create.deploying('create_new_age:redstone_magnet', ['minecraft:redstone_block', 'gtceu:steel_ingot'])

      //Primitive Wafer Cutting
      event.recipes.create.cutting(Item.of('gtceu:silicon_wafer', 4), 'gtceu:silicon_boule')

      //Asbestos Sheet Making
      event.recipes.create.sequenced_assembly([
        'kubejs:asbestos_sheet'
      ], 'gtceu:asbestos_dust', [
        event.recipes.createDeploying('gtceu:asbestos_dust', ['gtceu:asbestos_dust', 'gtceu:asbestos_dust'] ),
        event.recipes.createDeploying('gtceu:asbestos_dust', ['gtceu:asbestos_dust', 'minecraft:sand']),
        event.recipes.createDeploying('gtceu:asbestos_dust', ['gtceu:asbestos_dust', 'gtceu:stone_dust']),
        event.recipes.createFilling('gtceu:asbestos_dust', ['gtceu:asbestos_dust', Fluid.water(250)]),
        event.recipes.createPressing('gtceu:asbestos_dust','gtceu:asbestos_dust')
      ]).transitionalItem('gtceu:asbestos_dust').loops(1)

      //LV Heating Coils Making
      event.recipes.create.sequenced_assembly([
        'gtceu:cupronickel_coil_block'
      ], 'gtceu:lv_machine_casing', [
        event.recipes.createCutting('gtceu:lv_machine_casing','gtceu:lv_machine_casing'),
        event.recipes.createDeploying('gtceu:lv_machine_casing', ['gtceu:lv_machine_casing', 'gtceu:cupronickel_quadruple_wire']),
        event.recipes.createDeploying('gtceu:lv_machine_casing', ['gtceu:lv_machine_casing', 'kubejs:asbestos_sheet']),
        event.recipes.createPressing('gtceu:lv_machine_casing','gtceu:lv_machine_casing')
      ]).transitionalItem('gtceu:lv_machine_casing').loops(4)

      event.recipes.create.sequenced_assembly([
        'gtceu:duct_tape'
      ], 'gtceu:carbon_fibers', [
        event.recipes.createDeploying('gtceu:carbon_fibers', ['gtceu:carbon_fibers', 'gtceu:rubber_ingot'] ),
        event.recipes.createPressing('gtceu:carbon_fibers','gtceu:carbon_fibers'),
        event.recipes.createFilling('gtceu:carbon_fibers', ['gtceu:carbon_fibers', Fluid.of('gtceu:glue', 100)]),
        event.recipes.createPressing('gtceu:carbon_fibers','gtceu:carbon_fibers')
      ]).transitionalItem('gtceu:carbon_fibers').loops(1)

      

    



      //Gregtech Manual Recipes

      //EBF

      //Aluminium Smelting
      event.recipes.gtceu.electric_blast_furnace('aluminium_smelting')
      .itemInputs(
          'gtceu:raw_aluminium'
      )
      .itemOutputs(
        'gtceu:aluminium_ingot'
      )
      .duration(200)
      .EUt(100)
      .circuit(1)
      .blastFurnaceTemp(1600)

      event.recipes.gtceu.electric_blast_furnace('aluminium_dust_smelting')
      .itemInputs(
          'gtceu:aluminium_dust'
      )
      .itemOutputs(
        'gtceu:aluminium_ingot'
      )
      .duration(160)
      .EUt(100)
      .circuit(1)
      .blastFurnaceTemp(1600)

      //Circut Smelting
      event.recipes.gtceu.electric_blast_furnace('circut_smelting')
      .itemInputs(
          '8x gtceu:silicon_dust',
          'gtceu:gallium_arsenide_dust'
      )
      .itemOutputs(
        'gtceu:silicon_boule'
      )
      .duration(600)
      .EUt(120)
      .circuit(1)
      .blastFurnaceTemp(1800)

      //Lava Smelting
      event.recipes.gtceu.electric_blast_furnace('lava_melting')
      .itemInputs(
          '#forge:cobblestone'
      )
      .outputFluids(
        Fluid.of('minecraft:lava', 100)
      )
      .duration(50)
      .EUt(120)
      .circuit(1)
      .blastFurnaceTemp(1300)

      //Sturdy Sheet Smelting
      event.recipes.gtceu.electric_blast_furnace('sturdy_sheet_smelting')
      .itemInputs(
          'create:powdered_obsidian',
          'gtceu:stone_dust'
      )
      .itemOutputs(
        'create:sturdy_sheet'
      )
      .duration(100)
      .EUt(85)
      .circuit(1)
      .blastFurnaceTemp(1300)

      //Centrifuge
      //Sand Processing
      event.recipes.gtceu.centrifuge('sand_processing')
      .itemInputs(
          'minecraft:sand'
      )
      .chancedOutput('minecraft:gravel', 2000, 0)
      .chancedOutput('gtceu:silicon_dioxide_dust', 2000, 500)
      .duration(10)
      .EUt(15)
      
      //Gravel Processing
      event.recipes.gtceu.centrifuge('gravel_processing')
      .itemInputs(
          'minecraft:gravel'
      )
      .chancedOutput('minecraft:cobblestone', 1000, 0)
      .chancedOutput('minecraft:sand', 1000, 0)
      .chancedOutput('gtceu:stone_dust', 8000, 0)
      .duration(10)
      .EUt(15)
      
      //Ore Processing
      event.recipes.gtceu.centrifuge('gold_processing')
      .itemInputs(
          'create:crushed_raw_gold'
      )
      .itemOutputs(
          '9x minecraft:gold_nugget'
      )
      .chancedOutput('9x minecraft:gold_nugget', 2000, 4000)
      .chancedOutput('gtceu:arsenic_trioxide_dust', 5000, 1000)
      .duration(100)
      .EUt(15)

      event.recipes.gtceu.centrifuge('zinc_processing')
      .itemInputs(
          'create:crushed_raw_zinc'
      )
      .itemOutputs(
          '9x gtceu:zinc_nugget'
      )
      .chancedOutput('9x gtceu:zinc_nugget', 2000, 4000)
      .chancedOutput('gtceu:gallium_dust', 5000, 1000)
      .duration(100)
      .EUt(15)
      
      event.recipes.gtceu.centrifuge('aluminium_processing')
      .itemInputs(
          'gtceu:crushed_aluminium_ore'
      )
      .itemOutputs(
          'gtceu:aluminium_dust'
      )
      .chancedOutput('gtceu:aluminium_dust', 2000, 4000)
      .chancedOutput('gtceu:gallium_dust', 5000, 1000)
      .duration(100)
      .EUt(15)

      event.recipes.gtceu.centrifuge('copper_processing')
      .itemInputs(
          'create:crushed_raw_copper'
      )
      .itemOutputs(
          '9x create:copper_nugget'
      )
      .chancedOutput('9x create:copper_nugget', 2000, 4000)
      .chancedOutput('gtceu:arsenic_trioxide_dust', 2500, 500)
      .duration(100)
      .EUt(15)

      event.recipes.gtceu.centrifuge('iron_processing')
      .itemInputs(
          'create:crushed_raw_iron'
      )
      .itemOutputs(
          '9x minecraft:iron_nugget'
      )
      .chancedOutput('9x minecraft:iron_nugget', 2000, 4000)
      .chancedOutput('create:crushed_raw_gold', 1000, 500)
      .chancedOutput('create:crushed_raw_copper', 1000, 500)
      .duration(100)
      .EUt(15)

      //Coal Dust Processing
      event.recipes.gtceu.centrifuge('coal_processing')
      .itemInputs(
          'gtceu:coal_dust'
      )
      .chancedOutput('gtceu:carbon_dust', 6000, 1000)
      .chancedOutput('gtceu:stone_dust', 1000, 500)
      .duration(10)
      .EUt(15)

      //Glue Processing
      event.recipes.gtceu.centrifuge('glue_processing')
      .itemInputs(
          '4x minecraft:slime_ball'
      )
      .inputFluids(
        Fluid.of('minecraft:water', 500)
      )
      .outputFluids(
        Fluid.of('gtceu:glue', 500)
      )
      
      .duration(200)
      .EUt(5)


      //Alloy Smelter
      //Cheaper Steel Making
      event.recipes.gtceu.alloy_smelter('steelmaking')
        .itemInputs(
            'minecraft:iron_ingot',
            '2x gtceu:coal_dust'
        )
        .itemOutputs(
            'gtceu:steel_ingot'
        )
        .duration(100)
        .EUt(15)

      event.recipes.gtceu.alloy_smelter('rubbermaking')
      .itemInputs(
          '4x gtceu:wood_dust',
          'gtceu:sulfur_dust'

      )
      .itemOutputs(
          '4x gtceu:rubber_ingot'
      )
      .duration(50)
      .EUt(15)

      //Cheaper Brass Making
      event.recipes.gtceu.alloy_smelter('brassmaking')
      .itemInputs(
          'minecraft:copper_ingot',
          'gtceu:zinc_ingot'
      )
      .itemOutputs(
          '4x create:brass_ingot'
      )
      .duration(100)
      .EUt(15)

      //Cheaper Andesite Alloy Making
      event.recipes.gtceu.alloy_smelter('andesitealloymaking')
      .itemInputs(
          'minecraft:andesite',
          'minecraft:iron_nugget'
      )
      .itemOutputs(
          '2x create:andesite_alloy'
      )
      .duration(10)
      .EUt(15)

      //Cupronickel
      event.recipes.gtceu.alloy_smelter('blazepowdermaking')
      .itemInputs(
          'gtceu:coal_dust',
          'gtceu:sulfur_dust'
      )
      .itemOutputs(
          '2x minecraft:blaze_powder'
      )
      .duration(200)
      .EUt(30)
      
      //Invar
      event.recipes.gtceu.alloy_smelter('invarmaking')
      .itemInputs(
          'minecraft:iron_ingot',
          'gtceu:nickel_ingot'
      )
      .itemOutputs(
          '2x gtceu:invar_ingot'
      )
      .duration(200)
      .EUt(30)

      //Cupronickel
      event.recipes.gtceu.alloy_smelter('cupronickelmaking')
      .itemInputs(
          'minecraft:copper_ingot',
          'gtceu:nickel_ingot'
      )
      .itemOutputs(
          '2x gtceu:cupronickel_ingot'
      )
      .duration(200)
      .EUt(30)

      //Autoclave
      //Crystal Loop

      function CrystalProcessing(dust, crystal){
      //Seed Making
      event.recipes.create.sequenced_assembly([
        '4x ' + dust
      ], crystal, [
      event.recipes.createPressing(crystal, crystal)
      ]).transitionalItem(crystal).loops(3)

      //Crystal Synthesis
      event.recipes.gtceu.autoclave(crystal + '_processing')
      .itemInputs(
          dust
      )
      .inputFluids(
        Fluid.of('minecraft:lava', 100)
      )
      .itemOutputs(
        crystal
      )
      .duration(200)
      .EUt(32)
      }

      CrystalProcessing('gtceu:tiny_echo_shard_dust', 'minecraft:echo_shard')
      CrystalProcessing('gtceu:tiny_diamond_dust', 'minecraft:diamond')
      CrystalProcessing('gtceu:tiny_blaze_dust', 'minecraft:blaze_rod')
      CrystalProcessing('gtceu:tiny_emerald_dust', 'minecraft:emerald')
      CrystalProcessing('gtceu:tiny_ender_pearl_dust', 'minecraft:ender_pearl')
      CrystalProcessing('gtceu:tiny_nether_quartz_dust', 'minecraft:quartz')
      CrystalProcessing('gtceu:tiny_amethyst_dust', 'minecraft:amethyst_shard')

      //Carbon Fibers
      event.recipes.gtceu.autoclave('carbon_fiber_processing')
      .itemInputs(
          '3x gtceu:carbon_dust'
      )
      .itemOutputs(
        'gtceu:carbon_fibers'
      )
      .duration(100)
      .EUt(32)




      //Create New Age Energising
      //Arcane Ingots
      CreateEnergising("irons_spellbooks:arcane_ingot", 1, "gtceu:silver_ingot", 1, 20000)

      //Arcane Essence
      CreateEnergising("irons_spellbooks:arcane_essence", 4, "gtceu:silver_dust", 1, 10000)

      //Magnetic Iron Rods
      CreateEnergising("gtceu:magnetic_iron_rod", 1, "gtceu:iron_rod", 1, 100)
      
      //Magnetic Steel Rods
      CreateEnergising("gtceu:magnetic_steel_rod", 1, "gtceu:steel_rod", 1, 400)

      //LV Wafer Etching
      CreateEnergising("gtceu:cpu_chip", 1, "gtceu:silicon_wafer", 1, 10000)

      //LV Wafer Cutting
      CreateEnergising("gtceu:silicon_wafer", 8, "gtceu:silicon_boule", 1, 20000)






      //Polyethylene Production Line
      event.recipes.create.mixing(Fluid.of('gtceu:biomass', 100), [Item.of('minecraft:bone_meal', 2), Fluid.water(100)])

      event.recipes.create.mixing(Fluid.of('gtceu:ethanol', 50), [Fluid.of('gtceu:biomass', 100)]).heated()

      event.recipes.create.mixing([Fluid.of('gtceu:ethylene', 50), Fluid.of('gtceu:diluted_sulfuric_acid', 100)], [Fluid.of('gtceu:ethanol', 100), Fluid.of('gtceu:sulfuric_acid', 100)]).superheated()

      event.recipes.create.mixing([Fluid.of('gtceu:polyethylene', 100), Item.of('gtceu:silver_dust', 1).withChance(0.85)], [Fluid.of('gtceu:ethylene', 100), Item.of('gtceu:silver_dust', 1)]).heated()

      event.recipes.create.compacting('gtceu:polyethylene_ingot', [Fluid.of('gtceu:polyethylene', 100)])
      
      
  })