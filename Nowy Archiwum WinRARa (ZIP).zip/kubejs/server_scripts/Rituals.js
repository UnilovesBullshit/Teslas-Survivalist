ServerEvents.recipes((event) => {

//Enchanting gen
    function ApotheosisEnchanting(output, outputCount, input, Eterna, Quanta, Arcana){
        event.custom({
            "type": "apotheosis:enchanting",
            "conditions": [{
                "type": "apotheosis:module",
                "module": "enchantment"
            }],
            "input": {
                "item": input
            },
            "requirements": {
                "eterna": Eterna,
                "quanta": Quanta,
                "arcana": Arcana
            },
            "result": {
                "item": output,
                "count": outputCount
            }
            })
        }
        
    function AltApotheosisEnchanting(output, outputCount, input, minEterna, maxEtherna, minQuanta, maxQuanta, minArcana, maxArcana){
        event.custom({
            "type": "apotheosis:enchanting",
            "conditions": [{
                "type": "apotheosis:module",
                "module": "enchantment"
            }],
            "input": {
                "item": input
            },
            "requirements": {
                "eterna": minEterna,
                "quanta": minQuanta,
                "arcana": minArcana
            },
            "max_requirements": {
                "eterna": maxEtherna,
                "quanta": maxQuanta,
                "arcana": maxArcana
            },
            "result": {
                "item": output,
                "count": outputCount
            }
            })
        }

    //Ritual Generator
    event.recipes.occultism.ritual(
        'minecraft:blaze_spawn_egg',
        [
            "minecraft:gold_ingot",
            "minecraft:campfire",
            "minecraft:gold_ingot",
            "minecraft:campfire",
        ],
        'create_enchantment_industry:hyper_experience_bottle',
        'occultism:summon_foliot'
    )
    .dummy("kubejs:blaze_ritual")
    .useItem('minecraft:flint_and_steel')
    .duration(5)
    .command('execute summon minecraft:blaze summon minecraft:blaze summon minecraft:blaze summon minecraft:blaze run summon minecraft:lightning_bolt ~ ~ ~')
    .ritualType('occultism:execute_command')
    .id('occultism:summon_blaze')

    event.recipes.occultism.ritual(
        'minecraft:skeleton_spawn_egg',
        [
            "minecraft:bone",
            "minecraft:bone",
            "minecraft:bone",
            "minecraft:bone",
        ],
        'create_enchantment_industry:hyper_experience_bottle',
        'occultism:summon_foliot'
    )
    .dummy("kubejs:skeleton_ritual")
    .duration(5)
    .command('execute summon minecraft:skeleton summon minecraft:skeleton summon minecraft:skeleton run summon minecraft:skeleton')
    .ritualType('occultism:execute_command')
    .id('occultism:summon_skeleton')

    event.recipes.occultism.ritual(
        'minecraft:zombie_spawn_egg',
        [
            "minecraft:rotten_flesh",
            "minecraft:rotten_flesh",
            "minecraft:rotten_flesh",
            "minecraft:rotten_flesh",
        ],
        'create_enchantment_industry:hyper_experience_bottle',
        'occultism:summon_foliot'
    )
    .dummy("kubejs:zombie_ritual")
    .duration(5)
    .command('execute summon minecraft:zombie summon minecraft:zombie summon minecraft:zombie run summon minecraft:zombie')
    .ritualType('occultism:execute_command')
    .id('occultism:summon_zombie')

    //Apotheosis Enchanting
    //ApotheosisEnchanting(output, outputCount, input, Eterna, Quanta, Arcana) or AltApotheosisEnchanting(output, outputCount, input, minEterna, maxEtherna, minQuanta, maxQuanta, minArcana, maxArcana)
    ApotheosisEnchanting("irons_spellbooks:arcane_ingot", 2, "gtceu:silver_ingot", 7.5, 0, 50)

    ApotheosisEnchanting("irons_spellbooks:arcane_essence", 8, "gtceu:silver_dust", 7.5, 0, 50)

    ApotheosisEnchanting("irons_spellbooks:arcane_essence", 8, "gtceu:silver_dust", 5, 10, 10)

    ApotheosisEnchanting("minecraft:poisonous_potato", 1, "minecraft:potato", 1, 0, 0)

    ApotheosisEnchanting("irons_spellbooks:wandering_magician_helmet", 1, "minecraft:leather_helmet", 5, 10, 10)

    ApotheosisEnchanting("irons_spellbooks:wandering_magician_chestplate", 1, "minecraft:leather_chestplate", 5, 10, 10)

    ApotheosisEnchanting("irons_spellbooks:wandering_magician_leggings", 1, "minecraft:leather_leggings", 5, 10, 10)

    ApotheosisEnchanting("irons_spellbooks:wandering_magician_boots", 1, "minecraft:leather_boots", 5, 10, 10)

    ApotheosisEnchanting("irons_spellbooks:graybeard_staff", 1, "minecraft:leather_boots", 10, 0, 50)

    AltApotheosisEnchanting("irons_spellbooks:arcane_salvage", 1, "minecraft:netherite_scrap", 50, -1, 70, 100, 0, 20)
        
    //Spiritfire Cleansing
    event.recipes.occultism.spirit_fire('create_enchantment_industry:enchanting_guide', 'create:schedule')

    event.recipes.occultism.spirit_fire('irons_spellbooks:copper_spell_book', 'minecraft:enchanted_book')

    event.recipes.occultism.spirit_fire('irons_spellbooks:scroll_forge', 'minecraft:enchanting_table')


})