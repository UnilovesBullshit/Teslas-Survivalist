// priority: 0

// Visit the wiki for more info - https://kubejs.com/

ClientEvents.lang('en_us', event => {

    //item rename
    event.renameItem('create_new_age:basic_motor', 'LV Motor')
    event.renameItem('create_new_age:advanced_motor', 'MV Motor')
    event.renameItem('create_new_age:reinforced_motor', 'HV Motor')
    event.renameItem('create_new_age:energiser_t1', 'LV Energiser')
    event.renameItem('create_new_age:energiser_t2', 'MV Energiser')
    event.renameItem('create_new_age:energiser_t3', 'HV Energiser')




    //ritual naming
    event.add('ritual.occultism.summon_blaze.conditions', 'Not all requirements for this ritual are met.')
    event.add('ritual.occultism.summon_blaze.finished', 'Successfully summoned Blazes.')
    event.add('ritual.occultism.summon_blaze.interrupted', 'Blaze Summoning Interrupted.')
    event.add('ritual.occultism.summon_blaze.started', 'Use a Flint and Steel to initiate.')

    event.add('ritual.occultism.summon_skeleton.conditions', 'Not all requirements for this ritual are met.')
    event.add('ritual.occultism.summon_skeleton.finished', 'Successfully summoned Skeletons.')
    event.add('ritual.occultism.summon_skeleton.interrupted', 'Skeleton Summoning Interrupted.')
    event.add('ritual.occultism.summon_skeleton.started', 'Summoning Skeletons')
        
    

})

